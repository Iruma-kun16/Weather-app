# WasteMirror — Backend

AI-powered waste recognition and recycling prediction API built with Next.js + Groq.

---

## Architecture

```
wastemirror-backend/
├── app/
│   ├── layout.tsx                  # Minimal Next.js root layout
│   ├── page.tsx                    # API index page
│   └── api/
│       ├── scan/route.ts           # POST — AI waste image analysis (Groq vision)
│       ├── predict/route.ts        # POST — 1-year waste prediction
│       ├── leaderboard/route.ts    # GET  — Mock leaderboard
│       ├── rewards/route.ts        # GET/POST — Reward state & calculation
│       └── health/route.ts         # GET  — Health check
├── lib/
│   ├── groq.ts                     # Groq client singleton
│   ├── types.ts                    # All shared TypeScript types
│   ├── scanner.ts                  # Core AI waste scanning logic
│   ├── prediction.ts               # 1-year prediction formula + AI advice
│   └── rewards.ts                  # Levels, badges, leaderboard mock data
├── .env.local                      # Your secrets (not committed)
├── .env.example                    # Template
├── next.config.js                  # CORS + body size config
├── package.json
└── tsconfig.json
```

### What is real vs mocked

| Feature | Status |
|---|---|
| Waste image scanning | **Real AI** — Groq `meta-llama/llama-4-scout-17b-16e-instruct` (vision) |
| Item categorization | **Real AI** — structured JSON from vision model |
| Action suggestions | **Real AI** — item-specific, not generic |
| 1-year prediction | **Formula-based** — deterministic math, AI-generated advice text |
| Leaderboard | **Mock** — realistic Mongolian names/data |
| Rewards calculation | **Real logic** — formula, local state |

---

## Local Setup

### 1. Clone / copy files

```bash
git clone https://github.com/your-org/wastemirror-backend
cd wastemirror-backend
```

### 2. Install dependencies

```bash
npm install
```

### 3. Set environment variables

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
GROQ_API_KEY=gsk_your_key_here
```

### 4. Run dev server

```bash
npm run dev
```

API is now available at `http://localhost:3000/api/`

### 5. Verify

```bash
curl http://localhost:3000/api/health
```

---

## API Reference

### POST `/api/scan`

Analyze a waste image with AI.

**Request body:**
```json
{
  "image_base64": "data:image/jpeg;base64,/9j/4AAQ..."
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "item_name": "Хуучин утас",
    "item_name_en": "Old smartphone",
    "category": "electronics",
    "confidence": 92,
    "is_recyclable": true,
    "is_hazardous": false,
    "estimated_weight_kg": 0.18,
    "co2_saved_kg": 10.0,
    "actions": [
      {
        "method": "sellable",
        "title": "Засварын газарт зар",
        "title_en": "Sell to repair shop",
        "description": "Утсаа эвдрэлтэй ч засварын дэлгүүрт хэсэг болгон зарж болно.",
        "description_en": "Even broken, your phone can be sold to repair shops for parts.",
        "impact": "CO₂ 10кг хэмнэнэ",
        "impact_en": "Saves ~10kg of CO₂",
        "priority": "best"
      }
    ],
    "fun_fact": "Нэг ухаалаг утас 60 гаруй ховор металл агуулдаг.",
    "fun_fact_en": "A single smartphone contains over 60 rare earth elements.",
    "points_earned": 50,
    "exp_earned": 80
  }
}
```

**Image tips:** Send as `data:image/jpeg;base64,...` or raw base64 string. Max 5MB. JPEG/PNG/WEBP supported.

---

### POST `/api/predict`

Generate a 1-year waste/recycling prediction.

**Request body:**
```json
{
  "items_per_week": 5,
  "recycling_habit": "sometimes",
  "lifestyle": "student",
  "dominant_waste_category": "plastic",
  "scan_history": []
}
```

Field options:
- `recycling_habit`: `"none"` | `"sometimes"` | `"often"` | `"always"`
- `lifestyle`: `"student"` | `"office"` | `"family"` | `"other"`
- `dominant_waste_category`: `"electronics"` | `"plastic"` | `"paper"` | `"glass"` | `"metal"` | `"organic"` | `"textile"` | `"hazardous"` | `"furniture"` | `"mixed"` | `"unknown"`
- `scan_history` (optional): array of past scans with `{ category, estimated_weight_kg, is_recyclable, disposed_correctly }`

**Response:**
```json
{
  "success": true,
  "data": {
    "baseline": [
      { "label": "1 сар", "label_en": "1 Month", "total_waste_kg": 3.12, "recyclable_kg": 0.65, "landfill_kg": 2.47, "co2_emission_kg": 1.27, "co2_saved_if_improved_kg": 0.44, "improvement_percent": 34.2 },
      { "label": "6 сар", ... },
      { "label": "1 жил", ... }
    ],
    "improved": [ ... same structure, better numbers ... ],
    "summary_mn": "Та жилд 37.4 кг хог хаягдал үүсгэж байна...",
    "summary_en": "You generate approximately 37.4 kg of waste per year...",
    "ai_advice_mn": "Хуванцар хог хаягдлыг ангилж...",
    "ai_advice_en": "Sorting plastic waste and...",
    "weekly_waste_kg": 0.72,
    "recyclable_rate_percent": 20.9
  }
}
```

---

### GET `/api/leaderboard`

Returns mock leaderboard with 10 users + current demo user.

```json
{
  "success": true,
  "data": {
    "entries": [ { "rank": 1, "username": "Болд.Б", "level": 10, "exp": 8200, ... } ],
    "current_user": { "rank": 11, "username": "Та (Жишээ)", ... },
    "total_users": 1284
  }
}
```

---

### GET `/api/rewards`

Returns default user state and reward actions table.

---

### POST `/api/rewards`

Calculate updated reward state after completing an action.

**Request body:**
```json
{
  "current_exp": 145,
  "current_coins": 38,
  "action": "scan_item",
  "items_scanned": 5,
  "co2_saved_kg": 0.9,
  "streak_days": 2,
  "extra_co2": 10.0
}
```

Action options: `scan_item` | `follow_suggestion` | `daily_streak` | `room_photo` | `hazardous_correct`

---

### GET `/api/health`

Returns service status and endpoint list.

---

## Vercel Deployment

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "WasteMirror backend"
git remote add origin https://github.com/your-org/wastemirror-backend
git push -u origin main
```

### 2. Import on Vercel

1. Go to [vercel.com/new](https://vercel.com/new)
2. Import your repo
3. Framework preset: **Next.js** (auto-detected)
4. Add environment variable:
   - `GROQ_API_KEY` = your Groq key

### 3. Deploy

Click Deploy. Done.

Your API will be live at `https://your-project.vercel.app/api/`

---

## Frontend Integration

```typescript
// Scan a waste image
const res = await fetch('/api/scan', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ image_base64: base64String }),
});
const { success, data } = await res.json();

// Get prediction
const res2 = await fetch('/api/predict', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    items_per_week: 5,
    recycling_habit: 'sometimes',
    lifestyle: 'student',
    dominant_waste_category: 'plastic',
  }),
});

// Get leaderboard
const res3 = await fetch('/api/leaderboard');
```

If your frontend is on a different domain (e.g. frontend on Vercel, backend on separate deployment), CORS is pre-configured in `next.config.js` to allow all origins. You can tighten this for production.

---

## Demo Script for Judges

1. Open `/api/health` — show all endpoints are live
2. Upload a phone photo → `/api/scan` → show item name, category, actions, points
3. Fill prediction form → `/api/predict` → show baseline vs improved chart
4. Hit `/api/leaderboard` → show rankings
5. Show reward calculation via `POST /api/rewards`

**Key talking points:**
- Real AI (Groq Llama 4 Scout vision model) — not mocked
- Mongolian-first responses with English fallback
- Item-specific actions (not generic "just recycle it")
- Prediction is formula-based but AI generates personalized advice
- 5 endpoints, all under 500ms p95 on Vercel
