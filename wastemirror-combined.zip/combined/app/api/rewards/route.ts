import { NextRequest, NextResponse } from "next/server";
import { getDefaultUserRewards, REWARD_ACTIONS, getLevelFromExp, ALL_BADGES } from "@/lib/rewards";
import type { ApiResponse, UserRewardState } from "@/lib/types";

export const runtime = "nodejs";

// GET /api/rewards — return reward actions and default user state
export async function GET() {
  try {
    const defaultState = getDefaultUserRewards();
    return NextResponse.json<ApiResponse<{ user: UserRewardState; actions: typeof REWARD_ACTIONS }>>({
      success: true,
      data: {
        user: defaultState,
        actions: REWARD_ACTIONS,
      },
    });
  } catch (err) {
    console.error("[/api/rewards] Error:", err);
    return NextResponse.json<ApiResponse<null>>(
      { success: false, error: "Failed to fetch rewards.", code: "REWARDS_FAILED" },
      { status: 500 }
    );
  }
}

// POST /api/rewards/calculate — compute updated user state after an action
// Body: { current_exp: number, current_coins: number, action: string, extra_co2?: number }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { current_exp = 0, current_coins = 0, action, extra_co2 = 0 } = body;

    const rewardAction = REWARD_ACTIONS.find((r) => r.action === action);
    if (!rewardAction) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: `Unknown action: ${action}`, code: "UNKNOWN_ACTION" },
        { status: 400 }
      );
    }

    const new_exp    = current_exp + rewardAction.exp;
    const new_coins  = current_coins + rewardAction.points;
    const levelInfo  = getLevelFromExp(new_exp);

    // Determine which badges to unlock
    const unlockedBadgeIds: string[] = [];
    if (action === "scan_item" && current_exp === 0) unlockedBadgeIds.push("first_scan");
    if (levelInfo.level >= 5) unlockedBadgeIds.push("level_5");

    const badges = ALL_BADGES.map((b) => ({
      ...b,
      unlocked: unlockedBadgeIds.includes(b.id),
    }));

    const updatedState: UserRewardState = {
      coins:         new_coins,
      exp:           new_exp,
      level:         levelInfo.level,
      level_name_mn: levelInfo.name_mn,
      level_name_en: levelInfo.name_en,
      next_level_exp: levelInfo.next_level_exp,
      items_scanned: body.items_scanned ?? 0,
      co2_saved_kg:  (body.co2_saved_kg ?? 0) + extra_co2,
      streak_days:   body.streak_days ?? 0,
      badges,
    };

    return NextResponse.json<ApiResponse<{ updated: UserRewardState; gained: { exp: number; coins: number } }>>({
      success: true,
      data: {
        updated: updatedState,
        gained:  { exp: rewardAction.exp, coins: rewardAction.points },
      },
    });
  } catch (err) {
    console.error("[/api/rewards POST] Error:", err);
    return NextResponse.json<ApiResponse<null>>(
      { success: false, error: "Failed to calculate rewards.", code: "REWARDS_CALC_FAILED" },
      { status: 500 }
    );
  }
}
