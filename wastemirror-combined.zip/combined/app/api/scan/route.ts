import { NextRequest, NextResponse } from "next/server";
import { scanWasteImage } from "@/lib/scanner";
import type { ApiResponse, ScanResult } from "@/lib/types";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { image_base64 } = body as { image_base64?: string };

    if (!image_base64 || typeof image_base64 !== "string") {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "image_base64 field is required", code: "MISSING_IMAGE" },
        { status: 400 }
      );
    }

    // Basic size guard (~7.5MB base64 ≈ 5MB image)
    if (image_base64.length > 10_000_000) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "Image too large. Please use an image under 5MB.", code: "IMAGE_TOO_LARGE" },
        { status: 413 }
      );
    }

    const result = await scanWasteImage(image_base64);

    return NextResponse.json<ApiResponse<ScanResult>>({
      success: true,
      data: result,
    });
  } catch (err: unknown) {
    console.error("[/api/scan] Error:", err);
    const message = err instanceof Error ? err.message : "Unknown error";

    // Groq-specific errors
    if (message.includes("401") || message.includes("auth")) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "AI service authentication failed", code: "AUTH_ERROR" },
        { status: 500 }
      );
    }
    if (message.includes("rate") || message.includes("429")) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "AI service rate limit reached. Please try again shortly.", code: "RATE_LIMIT" },
        { status: 429 }
      );
    }

    return NextResponse.json<ApiResponse<null>>(
      { success: false, error: "Failed to analyze image. Please try again.", code: "SCAN_FAILED" },
      { status: 500 }
    );
  }
}

// Health check
export async function GET() {
  return NextResponse.json({ status: "ok", endpoint: "/api/scan" });
}
