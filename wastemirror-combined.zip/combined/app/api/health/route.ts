import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function GET() {
  const hasGroqKey = !!process.env.GROQ_API_KEY;

  return NextResponse.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    services: {
      groq: hasGroqKey ? "configured" : "missing_key",
    },
    endpoints: [
      { method: "POST", path: "/api/scan",        description: "Waste image AI analysis" },
      { method: "POST", path: "/api/predict",     description: "1-year waste prediction" },
      { method: "GET",  path: "/api/leaderboard", description: "Mock leaderboard" },
      { method: "GET",  path: "/api/rewards",     description: "Reward system state" },
      { method: "POST", path: "/api/rewards",     description: "Calculate reward after action" },
    ],
  });
}
