import { NextResponse } from "next/server";
import { getMockLeaderboard } from "@/lib/rewards";
import type { ApiResponse, LeaderboardResponse } from "@/lib/types";

export const runtime = "nodejs";

export async function GET() {
  try {
    const data = getMockLeaderboard();
    return NextResponse.json<ApiResponse<LeaderboardResponse>>({
      success: true,
      data,
    });
  } catch (err) {
    console.error("[/api/leaderboard] Error:", err);
    return NextResponse.json<ApiResponse<null>>(
      { success: false, error: "Failed to fetch leaderboard.", code: "LEADERBOARD_FAILED" },
      { status: 500 }
    );
  }
}
