import { NextRequest, NextResponse } from "next/server";
import { generatePrediction } from "@/lib/prediction";
import type { ApiResponse, PredictionResult, UserBehaviorInput, WasteCategory, RecyclingHabit, Lifestyle } from "@/lib/types";

export const runtime = "nodejs";

const VALID_CATEGORIES: WasteCategory[] = [
  "electronics","plastic","paper","glass","metal","organic","textile","hazardous","furniture","mixed","unknown"
];
const VALID_HABITS: RecyclingHabit[] = ["none","sometimes","often","always"];
const VALID_LIFESTYLES: Lifestyle[]   = ["student","office","family","other"];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as Partial<UserBehaviorInput>;

    // ─── Validation ────────────────────────────────────────────────────────────
    const items_per_week = Number(body.items_per_week);
    if (!Number.isFinite(items_per_week) || items_per_week < 0 || items_per_week > 1000) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "items_per_week must be a number between 0 and 1000", code: "INVALID_INPUT" },
        { status: 400 }
      );
    }

    const recycling_habit = body.recycling_habit ?? "sometimes";
    if (!VALID_HABITS.includes(recycling_habit)) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: `recycling_habit must be one of: ${VALID_HABITS.join(", ")}`, code: "INVALID_INPUT" },
        { status: 400 }
      );
    }

    const lifestyle = body.lifestyle ?? "other";
    if (!VALID_LIFESTYLES.includes(lifestyle)) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: `lifestyle must be one of: ${VALID_LIFESTYLES.join(", ")}`, code: "INVALID_INPUT" },
        { status: 400 }
      );
    }

    const dominant_waste_category = body.dominant_waste_category ?? "mixed";
    if (!VALID_CATEGORIES.includes(dominant_waste_category)) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: `dominant_waste_category must be one of: ${VALID_CATEGORIES.join(", ")}`, code: "INVALID_INPUT" },
        { status: 400 }
      );
    }

    const input: UserBehaviorInput = {
      items_per_week,
      recycling_habit,
      lifestyle,
      dominant_waste_category,
      scan_history: body.scan_history ?? [],
    };

    const result = await generatePrediction(input);

    return NextResponse.json<ApiResponse<PredictionResult>>({
      success: true,
      data: result,
    });
  } catch (err: unknown) {
    console.error("[/api/predict] Error:", err);
    return NextResponse.json<ApiResponse<null>>(
      { success: false, error: "Failed to generate prediction.", code: "PREDICT_FAILED" },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({ status: "ok", endpoint: "/api/predict" });
}
