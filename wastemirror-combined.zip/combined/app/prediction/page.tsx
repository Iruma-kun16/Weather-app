import Layout from "@/components/Layout";
import PredictionPage from "@/components/pages/PredictionPage";

export default function Prediction() {
  return (
    <Layout>
      <PredictionPage />
    </Layout>
  );
}
