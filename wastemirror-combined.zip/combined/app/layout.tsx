import type { Metadata } from "next";
import "./globals.css";
import NavLayout from "@/components/NavLayout";

export const metadata: Metadata = {
  title: "WasteMirror — Хог хаягдлаа ухаалгаар зохицуул",
  description: "AI-powered waste classification and sustainability app",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="mn">
      <body>
        <NavLayout>{children}</NavLayout>
      </body>
    </html>
  );
}
