import Layout from "@/components/Layout";
import RewardsPage from "@/components/pages/RewardsPage";

export default function Rewards() {
  return (
    <Layout>
      <RewardsPage />
    </Layout>
  );
}
