import Layout from "@/components/Layout";
import Landing from "@/components/pages/Landing";

export default function Home() {
  return (
    <Layout>
      <Landing />
    </Layout>
  );
}
