import Layout from "@/components/Layout";
import ScanPage from "@/components/pages/ScanPage";

export default function Scan() {
  return (
    <Layout>
      <ScanPage />
    </Layout>
  );
}
