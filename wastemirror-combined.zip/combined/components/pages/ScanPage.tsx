"use client";
import { useState, useRef } from "react";
import { ScanLine, Loader2, Sparkles, Camera, Upload, RotateCcw, Check, Home, ArrowRight, Recycle, Repeat, Wrench, Heart, DollarSign, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

// ── Image Uploader ──────────────────────────────────────────────────────────
function ImageUploader({ onImageCapture, label, sublabel }: {
  onImageCapture: (file: File, url: string, base64: string) => void;
  label?: string;
  sublabel?: string;
}) {
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setPreview(url);
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      onImageCapture(file, url, base64);
    };
    reader.readAsDataURL(file);
  };

  const reset = () => {
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    if (cameraInputRef.current) cameraInputRef.current.value = "";
  };

  if (preview) {
    return (
      <div className="relative rounded-2xl overflow-hidden border-2 border-primary/20 bg-card">
        <img src={preview} alt="Зураг" className="w-full max-h-80 object-cover" />
        <div className="absolute top-3 right-3">
          <Button size="sm" variant="secondary" onClick={reset} className="rounded-full shadow-lg bg-background/90 backdrop-blur">
            <RotateCcw className="w-4 h-4 mr-1.5" />
            Дахин
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {label && (
        <div className="text-center">
          <h3 className="text-base font-semibold text-foreground">{label}</h3>
          {sublabel && <p className="text-sm text-muted-foreground mt-1">{sublabel}</p>}
        </div>
      )}
      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => cameraInputRef.current?.click()}
          className="flex flex-col items-center gap-3 p-6 rounded-2xl border-2 border-dashed border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors cursor-pointer">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Camera className="w-7 h-7 text-primary" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground">Зураг авах</p>
            <p className="text-xs text-muted-foreground mt-0.5">Камер ашиглах</p>
          </div>
        </button>
        <button onClick={() => fileInputRef.current?.click()}
          className="flex flex-col items-center gap-3 p-6 rounded-2xl border-2 border-dashed border-border bg-muted/50 hover:bg-muted transition-colors cursor-pointer">
          <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center">
            <Upload className="w-7 h-7 text-muted-foreground" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground">Зураг сонгох</p>
            <p className="text-xs text-muted-foreground mt-0.5">Галерейгаас</p>
          </div>
        </button>
      </div>
      <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" onChange={handleFile} className="hidden" />
      <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
    </div>
  );
}

// ── Room Photo Prompt ────────────────────────────────────────────────────────
function RoomPhotoPrompt({ onComplete, completed }: { onComplete: () => void; completed: boolean }) {
  const [photo, setPhoto] = useState(false);

  if (completed) {
    return (
      <div className="bg-accent/50 border border-primary/20 rounded-2xl p-5 flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
          <Check className="w-6 h-6 text-primary" />
        </div>
        <div>
          <p className="text-sm font-semibold text-foreground">Өрөөний зураг амжилттай!</p>
          <p className="text-xs text-muted-foreground mt-0.5">Одоо хогоо скан хийх боломжтой</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border-2 border-primary/20 rounded-2xl p-6 space-y-5">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Home className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h3 className="text-base font-bold text-foreground">Эхлээд өрөөнийхөө зургийг авна уу</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Ширээн дээрх болон эргэн тойрон дахь зүйлсийг мэдэхийн тулд эхлээд нэг зураг авна уу.
          </p>
        </div>
      </div>
      <ImageUploader onImageCapture={() => setPhoto(true)} label="" />
      {photo && (
        <Button onClick={onComplete} className="w-full rounded-xl h-12 text-sm font-semibold">
          Үргэлжлүүлэх
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      )}
    </div>
  );
}

// ── Waste Result Card ─────────────────────────────────────────────────────────
const categoryLabels: Record<string, string> = {
  plastic: "Хуванцар", paper: "Цаас", metal: "Металл", glass: "Шил",
  organic: "Органик", electronics: "Цахилгаан хэрэгсэл", textile: "Нэхмэл",
  mixed: "Холимог", hazardous: "Аюултай", furniture: "Тавилга", other: "Бусад", unknown: "Тодорхойгүй",
};

const categoryColors: Record<string, string> = {
  plastic: "bg-blue-100 text-blue-700", paper: "bg-amber-100 text-amber-700",
  metal: "bg-slate-200 text-slate-700", glass: "bg-cyan-100 text-cyan-700",
  organic: "bg-green-100 text-green-700", electronics: "bg-purple-100 text-purple-700",
  textile: "bg-pink-100 text-pink-700", mixed: "bg-gray-100 text-gray-700",
  hazardous: "bg-red-100 text-red-700", unknown: "bg-gray-100 text-gray-700",
};

const methodIcons: Record<string, React.ElementType> = {
  reusable: Repeat, recyclable: Recycle, repairable: Wrench,
  donatable: Heart, sellable: DollarSign, compostable: Recycle, landfill: CheckCircle,
};

function WasteResultCard({ result }: { result: any }) {
  if (!result) return null;
  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
      <div className="p-5 border-b border-border">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-xl font-bold text-foreground">{result.item_name}</h3>
            {result.item_name_en && <p className="text-sm text-muted-foreground">{result.item_name_en}</p>}
            <div className="flex items-center gap-2 mt-2">
              <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${categoryColors[result.category] || "bg-gray-100 text-gray-700"}`}>
                {categoryLabels[result.category] || result.category}
              </span>
              {result.confidence != null && (
                <span className="text-xs text-muted-foreground">{result.confidence}% итгэлтэй</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-primary shrink-0">
            <Sparkles className="w-5 h-5" />
            <span className="text-sm font-bold">+{result.points_earned || 10}</span>
          </div>
        </div>
      </div>

      {result.actions && result.actions.length > 0 && (
        <div className="p-5 space-y-3">
          {result.actions.map((action: any, i: number) => {
            const Icon = methodIcons[action.method] || CheckCircle;
            const isBest = action.priority === "best";
            return (
              <div key={i} className={`rounded-xl p-4 ${isBest ? "bg-primary/5 border border-primary/20" : "bg-muted/50"}`}>
                {isBest && (
                  <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-1.5">✨ Хамгийн зөв алхам</p>
                )}
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${isBest ? "bg-primary/10" : "bg-muted"}`}>
                    <Icon className={`w-4 h-4 ${isBest ? "text-primary" : "text-muted-foreground"}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground">{action.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{action.description}</p>
                    {action.impact && (
                      <p className="text-xs text-primary mt-1 font-medium">🌱 {action.impact}</p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {result.fun_fact && (
        <div className="px-5 pb-5">
          <div className="bg-accent/30 rounded-xl p-4">
            <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-1">💡 Сонирхолтой баримт</p>
            <p className="text-sm text-foreground leading-relaxed">{result.fun_fact}</p>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Main Scan Page ────────────────────────────────────────────────────────────
export default function ScanPage() {
  const [roomDone, setRoomDone] = useState(false);
  const [wasteImage, setWasteImage] = useState<{ file: File; url: string; base64: string } | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const analyzeWaste = async () => {
    if (!wasteImage) return;
    setAnalyzing(true);
    setResult(null);
    setError(null);

    try {
      const res = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image_base64: wasteImage.base64 }),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || "Алдаа гарлаа");

      const scanResult = { ...data.data, image_url: wasteImage.url };

      // Save to localStorage history
      try {
        const existing = JSON.parse(localStorage.getItem("wastemirror_scans") || "[]");
        existing.unshift({ ...scanResult, id: Date.now(), created_date: new Date().toISOString() });
        localStorage.setItem("wastemirror_scans", JSON.stringify(existing.slice(0, 50)));
      } catch {}

      setResult(scanResult);
    } catch (err: any) {
      setError(err.message || "Шинжилгээ амжилтгүй болсон. Дахин оролдоно уу.");
    } finally {
      setAnalyzing(false);
    }
  };

  const resetScan = () => {
    setWasteImage(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 pb-28 md:pb-12 space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-3">
          <ScanLine className="w-3.5 h-3.5" />
          Хог таних
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground">Хогоо скан хийгээрэй</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Зураг авч илгээхэд AI таны хогийг таньж, юу хийхийг зөвлөнө
        </p>
      </div>

      {/* Step 1 */}
      <RoomPhotoPrompt onComplete={() => setRoomDone(true)} completed={roomDone} />

      {/* Step 2 */}
      {roomDone && !result && (
        <div className="space-y-4">
          <ImageUploader
            onImageCapture={(file, url, base64) => setWasteImage({ file, url, base64 })}
            label="Хогны зургийг авна уу"
            sublabel="Таних хүсэж буй хог эсвэл хуучин зүйлийнхээ зургийг авна уу"
          />

          {wasteImage && !analyzing && (
            <Button onClick={analyzeWaste} className="w-full rounded-xl h-12 text-base font-semibold shadow-lg shadow-primary/20">
              <Sparkles className="w-5 h-5 mr-2" />
              AI-гаар шинжлэх
            </Button>
          )}

          {analyzing && (
            <div className="flex flex-col items-center gap-4 py-12">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
              </div>
              <div className="text-center">
                <p className="text-sm font-semibold text-foreground">Шинжилж байна...</p>
                <p className="text-xs text-muted-foreground mt-1">AI таны зургийг боловсруулж байна</p>
              </div>
            </div>
          )}

          {error && (
            <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4 text-center">
              <p className="text-sm text-destructive font-medium">{error}</p>
            </div>
          )}
        </div>
      )}

      {/* Step 3: Result */}
      {result && (
        <div className="space-y-4">
          {/* Points */}
          <div className="bg-gradient-to-r from-primary/10 to-accent/30 rounded-2xl p-4 flex items-center justify-center gap-6">
            <div className="text-center">
              <p className="text-2xl font-black text-primary">+{result.points_earned}</p>
              <p className="text-xs text-muted-foreground">Зоос</p>
            </div>
            <div className="w-px h-10 bg-border" />
            <div className="text-center">
              <p className="text-2xl font-black text-primary">+{result.exp_earned}</p>
              <p className="text-xs text-muted-foreground">XP</p>
            </div>
            <div className="w-px h-10 bg-border" />
            <div className="text-center">
              <p className="text-2xl font-black text-primary">{result.co2_saved_kg}</p>
              <p className="text-xs text-muted-foreground">кг CO₂</p>
            </div>
          </div>

          <WasteResultCard result={result} />

          <Button onClick={resetScan} variant="outline" className="w-full rounded-xl h-12">
            Дахин скан хийх
          </Button>
        </div>
      )}
    </div>
  );
}
