"use client";
import { useState, useMemo } from "react";
import { BarChart3, Trash2, Recycle, TrendingDown, Leaf, ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

const lifestyleOptions = [
  { value: "student", label: "Оюутан" },
  { value: "office", label: "Оффисын ажилтан" },
  { value: "family", label: "Гэр бүл" },
  { value: "other", label: "Бусад" },
];

const recyclingHabits = [
  { value: "none", label: "Ангилдаггүй" },
  { value: "sometimes", label: "Заримдаа ангилдаг" },
  { value: "often", label: "Ихэвчлэн ангилдаг" },
  { value: "always", label: "Байнга ангилдаг" },
];

const wasteCategories = [
  { value: "mixed", label: "Холимог" },
  { value: "plastic", label: "Хуванцар" },
  { value: "paper", label: "Цаас" },
  { value: "organic", label: "Органик" },
  { value: "electronics", label: "Электроник" },
  { value: "metal", label: "Металл" },
  { value: "glass", label: "Шил" },
  { value: "textile", label: "Нэхмэл" },
];

function StatCard({ icon: Icon, label, value, unit, color = "text-primary" }: any) {
  return (
    <div className="bg-card border border-border rounded-2xl p-4 text-center">
      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-2">
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <p className="text-xl font-bold text-foreground">{value}</p>
      <p className="text-xs text-muted-foreground">{unit}</p>
      <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
    </div>
  );
}

export default function PredictionPage() {
  const [itemsPerWeek, setItemsPerWeek] = useState(8);
  const [lifestyle, setLifestyle] = useState("student");
  const [recycling, setRecycling] = useState("sometimes");
  const [category, setCategory] = useState("mixed");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchPrediction = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items_per_week: itemsPerWeek,
          recycling_habit: recycling,
          lifestyle,
          dominant_waste_category: category,
        }),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || "Алдаа");
      setResult(data.data);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  // Build chart data from result
  const chartData = useMemo(() => {
    if (!result) return [];
    return result.baseline.map((b: any, i: number) => ({
      name: b.label,
      "Одоогийн хог (кг)": b.landfill_kg,
      "Дахин боловсруулсан (кг)": b.recyclable_kg,
      "Сайжруулсан хог (кг)": result.improved[i].landfill_kg,
    }));
  }, [result]);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pb-28 md:pb-12 space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-3">
          <BarChart3 className="w-3.5 h-3.5" />
          Нэг жилийн таамаг
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground">Таны хог хаягдлын нөлөөлөл</h1>
        <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
          Өөрийн зан үйлд тулгуурлан нэг жилийн хог хаягдлын хэмжээгээ тооцоолоорой
        </p>
      </div>

      {/* Input form */}
      <div className="bg-card border border-border rounded-2xl p-6 space-y-6">
        <h3 className="text-base font-bold text-foreground">Таны мэдээлэл</h3>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-foreground">Долоо хоногт хаядаг зүйлийн тоо</label>
            <span className="text-lg font-bold text-primary">{itemsPerWeek}</span>
          </div>
          <Slider value={[itemsPerWeek]} onValueChange={(v) => setItemsPerWeek(v[0])} min={1} max={30} step={1} className="w-full" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>1 зүйл</span><span>30 зүйл</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Амьдралын хэв маяг</label>
            <Select value={lifestyle} onValueChange={setLifestyle}>
              <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
              <SelectContent>
                {lifestyleOptions.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Хог ангилах зуршил</label>
            <Select value={recycling} onValueChange={setRecycling}>
              <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
              <SelectContent>
                {recyclingHabits.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Голлох хог төрөл</label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
              <SelectContent>
                {wasteCategories.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={fetchPrediction} disabled={loading} className="w-full rounded-xl h-12 text-sm font-semibold">
          {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Тооцоолж байна...</> : <>Таамаг харах <ArrowRight className="w-4 h-4 ml-2" /></>}
        </Button>
        {error && <p className="text-sm text-destructive text-center">{error}</p>}
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-6">
          <div className="bg-accent/40 rounded-2xl p-4 text-center">
            <p className="text-sm text-foreground font-medium">{result.summary_mn}</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard icon={Trash2} label="Нэг жилийн хог" value={result.baseline[2].total_waste_kg} unit="кг" />
            <StatCard icon={Recycle} label="Дахин боловсруулсан" value={result.baseline[2].recyclable_kg} unit="кг" />
            <StatCard icon={TrendingDown} label="Бууруулах боломж" value={Math.round((result.baseline[2].co2_saved_if_improved_kg) * 10) / 10} unit="кг CO₂" />
            <StatCard icon={Leaf} label="Дахин боловсруулалт" value={result.recyclable_rate_percent} unit="%" />
          </div>

          {/* Chart */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="text-base font-bold text-foreground mb-1">Хог хаягдлын таамаг</h3>
            <p className="text-xs text-muted-foreground mb-4">1 сар / 6 сар / 1 жилийн харьцуулалт</p>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorWaste" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorImproved" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorRecycled" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Area type="monotone" dataKey="Одоогийн хог (кг)" stroke="#ef4444" fill="url(#colorWaste)" strokeWidth={2} />
                <Area type="monotone" dataKey="Сайжруулсан хог (кг)" stroke="#22c55e" fill="url(#colorImproved)" strokeWidth={2} />
                <Area type="monotone" dataKey="Дахин боловсруулсан (кг)" stroke="#3b82f6" fill="url(#colorRecycled)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* AI Advice */}
          {result.ai_advice_mn && (
            <div className="bg-gradient-to-br from-primary/10 to-accent/30 rounded-2xl p-6">
              <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-2">🤖 AI зөвлөгөө</p>
              <p className="text-sm text-foreground leading-relaxed">{result.ai_advice_mn}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
