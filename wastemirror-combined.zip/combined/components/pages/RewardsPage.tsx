"use client";
import { useState, useEffect } from "react";
import { Trophy, History, Coins, Zap, Star, Medal } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";

const LEVELS = [
  { level: 1, name_mn: "Шинэхэн", min_exp: 0 },
  { level: 2, name_mn: "Эко Анхлан", min_exp: 100 },
  { level: 3, name_mn: "Ногоон Гарваа", min_exp: 250 },
  { level: 4, name_mn: "Дахин Ашиглагч", min_exp: 500 },
  { level: 5, name_mn: "Хаягдлын Баатар", min_exp: 900 },
  { level: 6, name_mn: "Эко Дайчин", min_exp: 1400 },
  { level: 7, name_mn: "Нөхөн Сэргэгч", min_exp: 2000 },
  { level: 8, name_mn: "Дэлхийн Эзэн", min_exp: 3000 },
  { level: 9, name_mn: "Устгагч Тэнгэр", min_exp: 4500 },
  { level: 10, name_mn: "Эко Аварга", min_exp: 6500 },
];

function getLevelFromExp(exp: number) {
  let current = LEVELS[0];
  for (const l of LEVELS) { if (exp >= l.min_exp) current = l; }
  const idx = LEVELS.indexOf(current);
  const next = LEVELS[idx + 1];
  return { ...current, next_level_exp: next?.min_exp ?? current.min_exp };
}

const rankColors: Record<number, string> = {
  1: "bg-amber-400 text-white",
  2: "bg-slate-400 text-white",
  3: "bg-amber-600 text-white",
};

export default function RewardsPage() {
  const [scans, setScans] = useState<any[]>([]);
  const [leaderboard, setLeaderboard] = useState<any>(null);
  const [loadingLB, setLoadingLB] = useState(true);

  // Load scans from localStorage
  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem("wastemirror_scans") || "[]");
      setScans(stored);
    } catch {}
  }, []);

  // Load leaderboard from backend
  useEffect(() => {
    fetch("/api/leaderboard")
      .then((r) => r.json())
      .then((d) => { if (d.success) setLeaderboard(d.data); })
      .catch(() => {})
      .finally(() => setLoadingLB(false));
  }, []);

  const totalCoins = scans.reduce((s, x) => s + (x.points_earned || 0), 0);
  const totalExp = scans.reduce((s, x) => s + (x.exp_earned || 0), 0);
  const totalScans = scans.length;
  const levelInfo = getLevelFromExp(totalExp);
  const progress = levelInfo.next_level_exp > levelInfo.min_exp
    ? ((totalExp - levelInfo.min_exp) / (levelInfo.next_level_exp - levelInfo.min_exp)) * 100
    : 100;

  const entries = leaderboard?.entries || [];
  // Inject player into leaderboard with real stats
  const playerEntry = leaderboard?.current_user
    ? { ...leaderboard.current_user, exp: totalExp, coins: totalCoins, items_scanned: totalScans, is_current_user: true }
    : null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pb-28 md:pb-12 space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-3">
          <Trophy className="w-3.5 h-3.5" />
          Шагнал
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground">Миний ахиц дэвшил</h1>
        <p className="mt-2 text-sm text-muted-foreground">Скан хийх бүрт зоос, туршлага цуглуулж түвшнээ ахиулаарай</p>
      </div>

      {/* Level Card */}
      <div className="bg-card border border-border rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Star className="w-7 h-7 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Түвшин {levelInfo.level}</p>
              <p className="text-lg font-bold text-foreground">{levelInfo.name_mn}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-primary">{totalCoins}</p>
            <p className="text-xs text-muted-foreground">Зоос</p>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">{totalExp} XP</span>
            <span className="text-muted-foreground">{levelInfo.next_level_exp} XP</span>
          </div>
          <Progress value={Math.min(100, progress)} className="h-2.5" />
          {levelInfo.level < 10 && (
            <p className="text-xs text-muted-foreground text-center">
              Дараагийн түвшин: <span className="font-semibold text-foreground">{LEVELS[levelInfo.level]?.name_mn}</span>
            </p>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { icon: Coins, val: totalCoins, label: "Нийт зоос" },
          { icon: Zap, val: totalExp, label: "Нийт XP" },
          { icon: History, val: totalScans, label: "Нийт скан" },
        ].map(({ icon: Icon, val, label }, i) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-4 text-center">
            <Icon className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-xl font-bold text-foreground">{val}</p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="leaderboard" className="w-full">
        <TabsList className="w-full rounded-xl bg-muted h-11">
          <TabsTrigger value="leaderboard" className="flex-1 rounded-lg text-sm">Тэргүүлэгчид</TabsTrigger>
          <TabsTrigger value="history" className="flex-1 rounded-lg text-sm">Миний түүх</TabsTrigger>
        </TabsList>

        <TabsContent value="leaderboard" className="mt-4">
          {loadingLB ? (
            <div className="flex justify-center py-12">
              <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              <div className="px-6 py-4 border-b border-border flex items-center gap-2.5">
                <Trophy className="w-5 h-5 text-primary" />
                <h3 className="text-base font-bold text-foreground">Тэргүүлэгчид</h3>
                <span className="ml-auto text-xs text-muted-foreground">{leaderboard?.total_users?.toLocaleString()} хэрэглэгч</span>
              </div>
              <div className="divide-y divide-border">
                {[...entries].map((user: any, i: number) => (
                  <div key={i}
                    className={`flex items-center gap-4 px-6 py-3.5 transition-colors ${user.is_current_user ? "bg-primary/5" : "hover:bg-muted/50"}`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${rankColors[user.rank] || "bg-muted text-muted-foreground"}`}>
                      {user.rank <= 3 ? <Medal className="w-4 h-4" /> : user.rank}
                    </div>
                    <div className="text-xl">{user.avatar}</div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-semibold truncate ${user.is_current_user ? "text-primary" : "text-foreground"}`}>
                        {user.username} {user.is_current_user && "👈 Та"}
                      </p>
                      <p className="text-xs text-muted-foreground">Түвшин {user.level} · {user.badge}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold text-foreground">{user.exp.toLocaleString()} XP</p>
                      <p className="text-xs text-muted-foreground">{user.items_scanned} скан</p>
                    </div>
                  </div>
                ))}
                {playerEntry && (
                  <div className="flex items-center gap-4 px-6 py-3.5 bg-primary/5 border-t-2 border-primary/20">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold bg-primary text-white">
                      {playerEntry.rank}
                    </div>
                    <div className="text-xl">{playerEntry.avatar}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-primary truncate">{playerEntry.username} 👈 Та</p>
                      <p className="text-xs text-muted-foreground">Түвшин {levelInfo.level} · {levelInfo.name_mn}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold text-foreground">{totalExp} XP</p>
                      <p className="text-xs text-muted-foreground">{totalScans} скан</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          {scans.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-12 text-center">
              <History className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-base font-semibold text-foreground">Одоохондоо түүх байхгүй</p>
              <p className="text-sm text-muted-foreground mt-1">Эхний скан хийхэд энд харагдана</p>
            </div>
          ) : (
            <div className="space-y-3">
              {scans.map((scan, i) => (
                <div key={scan.id || i} className="bg-card border border-border rounded-2xl p-4 flex items-center gap-4">
                  {scan.image_url ? (
                    <img src={scan.image_url} alt={scan.item_name} className="w-14 h-14 rounded-xl object-cover shrink-0" />
                  ) : (
                    <div className="w-14 h-14 rounded-xl bg-muted flex items-center justify-center shrink-0">
                      <History className="w-6 h-6 text-muted-foreground" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">{scan.item_name || "Тодорхойгүй"}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{scan.category}</p>
                    {scan.co2_saved_kg && (
                      <p className="text-xs text-primary mt-0.5">🌱 {scan.co2_saved_kg} кг CO₂ хэмнэсэн</p>
                    )}
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold text-primary">+{scan.points_earned || 0}</p>
                    <p className="text-xs text-muted-foreground">зоос</p>
                    <p className="text-xs text-muted-foreground">+{scan.exp_earned || 0} XP</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
