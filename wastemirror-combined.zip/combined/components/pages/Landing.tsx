"use client";
import Link from "next/link";
import { ScanLine, Lightbulb, BarChart3, Trophy, ArrowRight, Leaf, Recycle, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const features = [
  { icon: ScanLine, title: "Хог таних", desc: "Зураг авахад л хангалттай. AI таны хогийг ангилна." },
  { icon: Lightbulb, title: "Ухаалаг зөвлөгөө", desc: "Хаяхын оронд юу хийх вэ? Бодит сонголтуудыг санал болгоно." },
  { icon: BarChart3, title: "Нэг жилийн таамаг", desc: "Таны зан үйл дээр тулгуурлан хог хаягдлын хэмжээг таамаглана." },
  { icon: Trophy, title: "Шагнал ба түвшин", desc: "Дахин боловсруулах бүрт оноо цуглуулж, түвшнээ ахиулна." },
];

const stats = [
  { value: "2.1B", label: "тонн хог/жил дэлхий даяар" },
  { value: "12%", label: "л нь дахин боловсруулагддаг" },
  { value: "80%", label: "хогийг бууруулах боломжтой" },
];

export default function Landing() {
  return (
    <div className="pb-24 md:pb-12">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/30" />
        <div className="relative max-w-6xl mx-auto px-4 py-20 md:py-32">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-6">
              <Leaf className="w-3.5 h-3.5" />
              Хакатон прототип 2026
            </div>
            <h1 className="text-4xl md:text-6xl font-black tracking-tight text-foreground leading-tight">
              Хогоо{" "}
              <span className="text-primary">ухаалгаар</span>
              <br />
              зохицуул
            </h1>
            <p className="mt-5 text-lg md:text-xl text-muted-foreground leading-relaxed max-w-lg">
              WasteMirror нь зураг авахад л хог хаягдлыг таньж, дахин ашиглах аргыг зөвлөж, таны ирээдүйн нөлөөллийг тооцоолно.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/scan">
                <Button size="lg" className="rounded-xl h-12 px-8 text-base font-semibold shadow-lg shadow-primary/20">
                  <ScanLine className="w-5 h-5 mr-2" />
                  Скан эхлэх
                </Button>
              </Link>
              <Link href="/prediction">
                <Button size="lg" variant="outline" className="rounded-xl h-12 px-8 text-base font-semibold">
                  Таамаг харах
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>

          <div className="hidden lg:block absolute right-12 top-1/2 -translate-y-1/2">
            <div className="relative w-80 h-80">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/20 to-accent/40" />
              <div className="absolute inset-6 rounded-full bg-gradient-to-br from-primary/10 to-transparent flex items-center justify-center">
                <Recycle className="w-32 h-32 text-primary/30" />
              </div>
              <Sparkles className="w-6 h-6 text-primary/50 absolute top-4 left-1/2" />
              <Leaf className="w-5 h-5 text-primary/40 absolute bottom-8 right-8" />
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-6xl mx-auto px-4 -mt-4 md:-mt-8">
        <div className="grid grid-cols-3 gap-3 md:gap-6">
          {stats.map((stat, i) => (
            <div key={i} className="bg-card border border-border rounded-2xl p-4 md:p-6 text-center">
              <p className="text-2xl md:text-3xl font-black text-primary">{stat.value}</p>
              <p className="text-xs md:text-sm text-muted-foreground mt-1">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-4 py-20 md:py-28">
        <div className="text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">Яаж ажилладаг вэ?</h2>
          <p className="mt-3 text-muted-foreground max-w-md mx-auto">
            Дөрвөн энгийн алхмаар хогоо ухаалгаар зохицуулаарай
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((feature, i) => (
            <div key={i} className="bg-card border border-border rounded-2xl p-6 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 group">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <feature.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-base font-bold text-foreground mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-4 pb-12">
        <div className="bg-gradient-to-br from-primary to-primary/80 rounded-3xl p-8 md:p-14 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white">Хогоо хаяхаасаа өмнө нэг бод</h2>
          <p className="mt-3 text-white/80 max-w-md mx-auto">
            WasteMirror ашиглан хог хаягдлаа бууруулж, байгаль орчиндоо хувь нэмэр оруулаарай.
          </p>
          <Link href="/scan">
            <Button size="lg" variant="secondary" className="mt-6 rounded-xl h-12 px-8 text-base font-semibold">
              Одоо эхлэх
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
