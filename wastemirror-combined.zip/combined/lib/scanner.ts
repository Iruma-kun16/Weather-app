import { groq, VISION_MODEL } from "./groq";
import type { ScanResult, WasteCategory, WasteAction, DisposalMethod } from "./types";

// ─── Points table per category ─────────────────────────────────────────────────
const POINTS_TABLE: Record<WasteCategory, { points: number; exp: number }> = {
  electronics: { points: 50, exp: 80 },
  hazardous:   { points: 60, exp: 90 },
  plastic:     { points: 20, exp: 30 },
  paper:       { points: 15, exp: 20 },
  glass:       { points: 25, exp: 35 },
  metal:       { points: 30, exp: 45 },
  organic:     { points: 10, exp: 15 },
  textile:     { points: 25, exp: 40 },
  furniture:   { points: 40, exp: 60 },
  mixed:       { points: 15, exp: 20 },
  unknown:     { points: 5,  exp: 5  },
};

// ─── CO₂ savings estimate per category (kg) ────────────────────────────────────
const CO2_SAVINGS: Record<WasteCategory, number> = {
  electronics: 10.0,
  plastic:      0.5,
  paper:        0.3,
  glass:        0.8,
  metal:        2.0,
  organic:      0.2,
  textile:      3.0,
  hazardous:    5.0,
  furniture:    4.0,
  mixed:        0.5,
  unknown:      0.1,
};

// ─── Prompt builder ────────────────────────────────────────────────────────────
function buildPrompt(): string {
  return `You are WasteMirror AI — a waste classification and sustainability expert.

Analyze the image and return ONLY a valid JSON object with NO markdown, NO extra text, NO code fences.

The JSON must follow this exact schema:
{
  "item_name": "string (Mongolian name of the item)",
  "item_name_en": "string (English name)",
  "category": "one of: electronics|plastic|paper|glass|metal|organic|textile|hazardous|furniture|mixed|unknown",
  "confidence": number (0-100),
  "is_recyclable": boolean,
  "is_hazardous": boolean,
  "estimated_weight_kg": number,
  "actions": [
    {
      "method": "one of: reusable|recyclable|repairable|donatable|sellable|compostable|landfill",
      "title": "short action title in Mongolian",
      "title_en": "short action title in English",
      "description": "1-2 sentence practical advice in Mongolian. Be specific, not generic.",
      "description_en": "1-2 sentence practical advice in English. Be specific, not generic.",
      "impact": "estimated environmental impact in Mongolian (e.g. CO₂ 2кг хэмнэнэ)",
      "impact_en": "estimated environmental impact in English",
      "priority": "best or alternative"
    }
  ],
  "fun_fact": "interesting eco fact about this item type in Mongolian",
  "fun_fact_en": "interesting eco fact about this item type in English"
}

Rules:
- Provide 3-5 actions total. First action must have priority "best", rest are "alternative"
- actions must be SPECIFIC to this item. For a broken phone: sell for parts, donate to e-waste, strip for metals. NOT generic "recycle".
- For electronics/appliances: always include sell/repair options
- For clothing: include donate, resell, repurpose options
- For food waste: composting first
- For hazardous (batteries, paint, chemicals): always warn about proper disposal
- Be practical for a Mongolian user context
- confidence should reflect how sure you are about the item identification`;
}

// ─── Main scan function ────────────────────────────────────────────────────────
export async function scanWasteImage(imageBase64: string): Promise<ScanResult> {
  // Strip data URL prefix if present
  const base64Data = imageBase64.includes(",")
    ? imageBase64.split(",")[1]
    : imageBase64;

  // Determine media type
  const mediaType = imageBase64.startsWith("data:image/png")
    ? "image/png"
    : imageBase64.startsWith("data:image/webp")
    ? "image/webp"
    : imageBase64.startsWith("data:image/gif")
    ? "image/gif"
    : "image/jpeg";

  const response = await groq.chat.completions.create({
    model: VISION_MODEL,
    max_tokens: 2048,
    temperature: 0.2, // low temp = more consistent structured output
    messages: [
      {
        role: "user",
        content: [
          {
            type: "image_url",
            image_url: {
              url: `data:${mediaType};base64,${base64Data}`,
            },
          },
          {
            type: "text",
            text: buildPrompt(),
          },
        ],
      },
    ],
  });

  const raw = response.choices[0]?.message?.content ?? "";

  // Parse JSON — strip any accidental markdown fences
  const cleaned = raw
    .replace(/```json\s*/gi, "")
    .replace(/```\s*/gi, "")
    .trim();

  let parsed: Partial<ScanResult & { actions: WasteAction[] }>;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    // Fallback: extract JSON substring
    const match = cleaned.match(/\{[\s\S]*\}/);
    if (!match) throw new Error("AI returned unparseable response");
    parsed = JSON.parse(match[0]);
  }

  const category: WasteCategory = parsed.category ?? "unknown";
  const rewards = POINTS_TABLE[category];
  const co2 = CO2_SAVINGS[category];

  return {
    item_name:           parsed.item_name ?? "Тодорхойгүй зүйл",
    item_name_en:        parsed.item_name_en ?? "Unknown item",
    category,
    confidence:          Math.min(100, Math.max(0, parsed.confidence ?? 70)),
    is_recyclable:       parsed.is_recyclable ?? false,
    is_hazardous:        parsed.is_hazardous ?? false,
    estimated_weight_kg: parsed.estimated_weight_kg ?? 0.5,
    co2_saved_kg:        co2,
    actions:             parsed.actions ?? [],
    fun_fact:            parsed.fun_fact ?? "",
    fun_fact_en:         parsed.fun_fact_en ?? "",
    points_earned:       rewards.points,
    exp_earned:          rewards.exp,
  };
}
