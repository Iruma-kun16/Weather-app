import Groq from "groq-sdk";

if (!process.env.GROQ_API_KEY) {
  throw new Error("GROQ_API_KEY environment variable is not set");
}

export const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY,
});

// Primary vision model — supports image input
export const VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct";

// Text model for prediction/analysis (fast, cheap)
export const TEXT_MODEL = "llama-3.3-70b-versatile";
