import { groq, TEXT_MODEL } from "./groq";
import type {
  UserBehaviorInput,
  PredictionResult,
  PredictionPeriod,
  WasteCategory,
  RecyclingHabit,
} from "./types";

// ─── Weight averages per category (kg per item) ────────────────────────────────
const AVG_WEIGHT: Record<WasteCategory, number> = {
  electronics: 0.8,
  plastic:     0.15,
  paper:       0.2,
  glass:       0.4,
  metal:       0.5,
  organic:     0.3,
  textile:     0.6,
  hazardous:   0.25,
  furniture:   8.0,
  mixed:       0.3,
  unknown:     0.3,
};

// ─── Recyclable fraction per category ─────────────────────────────────────────
const RECYCLABLE_FRACTION: Record<WasteCategory, number> = {
  electronics: 0.85,
  plastic:     0.70,
  paper:       0.90,
  glass:       0.95,
  metal:       0.95,
  organic:     0.60, // compostable
  textile:     0.65,
  hazardous:   0.50,
  furniture:   0.40,
  mixed:       0.45,
  unknown:     0.30,
};

// ─── CO₂ per kg landfill (kg CO₂ per kg waste) ────────────────────────────────
const CO2_PER_KG_LANDFILL = 0.5;
const CO2_PER_KG_RECYCLED = 0.05; // much lower

// ─── Recycling habit multiplier (how much user actually recycles) ──────────────
const HABIT_MULTIPLIER: Record<RecyclingHabit, number> = {
  none:      0.05,
  sometimes: 0.30,
  often:     0.65,
  always:    0.90,
};

// ─── Lifestyle items-per-week baseline adjustments ────────────────────────────
const LIFESTYLE_MULTIPLIER = {
  student: 1.0,
  office:  1.2,
  family:  2.0,
  other:   1.0,
};

// ─── Build one period ──────────────────────────────────────────────────────────
function buildPeriod(
  label: string,
  label_en: string,
  weeks: number,
  weeklyWasteKg: number,
  actualRecycleFraction: number,
  improvedRecycleFraction: number,
  isImproved: boolean
): PredictionPeriod {
  const fraction = isImproved ? improvedRecycleFraction : actualRecycleFraction;
  const total_waste_kg     = parseFloat((weeklyWasteKg * weeks).toFixed(2));
  const recyclable_kg      = parseFloat((total_waste_kg * fraction).toFixed(2));
  const landfill_kg        = parseFloat((total_waste_kg - recyclable_kg).toFixed(2));
  const co2_emission_kg    = parseFloat((
    landfill_kg * CO2_PER_KG_LANDFILL +
    recyclable_kg * CO2_PER_KG_RECYCLED
  ).toFixed(2));

  // What CO₂ would be saved if they improved
  const improved_recyclable = total_waste_kg * improvedRecycleFraction;
  const improved_landfill   = total_waste_kg - improved_recyclable;
  const improved_co2        = improved_landfill * CO2_PER_KG_LANDFILL + improved_recyclable * CO2_PER_KG_RECYCLED;
  const co2_saved_if_improved_kg = parseFloat((co2_emission_kg - improved_co2).toFixed(2));

  const improvement_percent = parseFloat(
    (((improvedRecycleFraction - fraction) / Math.max(fraction, 0.01)) * 100).toFixed(1)
  );

  return {
    label,
    label_en,
    total_waste_kg,
    recyclable_kg,
    landfill_kg,
    co2_emission_kg,
    co2_saved_if_improved_kg: Math.max(0, co2_saved_if_improved_kg),
    improvement_percent: Math.max(0, improvement_percent),
  };
}

// ─── Main prediction function ──────────────────────────────────────────────────
export async function generatePrediction(
  input: UserBehaviorInput
): Promise<PredictionResult> {
  const {
    items_per_week,
    recycling_habit,
    lifestyle,
    dominant_waste_category,
    scan_history = [],
  } = input;

  // Weekly waste in kg
  const avgWeight     = AVG_WEIGHT[dominant_waste_category];
  const lifestyleMult = LIFESTYLE_MULTIPLIER[lifestyle];
  const weeklyWasteKg = items_per_week * avgWeight * lifestyleMult;

  // Actual recycle fraction = habit x category recyclability
  const habitMult        = HABIT_MULTIPLIER[recycling_habit];
  const maxRecyclable    = RECYCLABLE_FRACTION[dominant_waste_category];
  const actualFraction   = habitMult * maxRecyclable;

  // Improved fraction: assume user follows app suggestions (80% of max)
  const improvedFraction = Math.min(maxRecyclable * 0.85, 0.95);

  // Adjust using scan history if available
  let historyAdjustedFraction = actualFraction;
  if (scan_history.length > 0) {
    const correctlyDisposed = scan_history.filter((s) => s.disposed_correctly).length;
    const historyFraction   = correctlyDisposed / scan_history.length;
    // Blend 50/50 with formula
    historyAdjustedFraction = (actualFraction + historyFraction) / 2;
  }

  const periods = [
    { label: "1 сар", label_en: "1 Month", weeks: 4 },
    { label: "6 сар", label_en: "6 Months", weeks: 26 },
    { label: "1 жил", label_en: "1 Year", weeks: 52 },
  ];

  const baseline = periods.map((p) =>
    buildPeriod(p.label, p.label_en, p.weeks, weeklyWasteKg, historyAdjustedFraction, improvedFraction, false)
  );

  const improved = periods.map((p) =>
    buildPeriod(p.label, p.label_en, p.weeks, weeklyWasteKg, historyAdjustedFraction, improvedFraction, true)
  );

  const recyclable_rate_percent = parseFloat((historyAdjustedFraction * 100).toFixed(1));
  const yearly = baseline[2];

  // ─── AI-generated personalized advice ───────────────────────────────────────
  let ai_advice_mn = "";
  let ai_advice_en = "";
  let summary_mn   = "";
  let summary_en   = "";

  try {
    const advicePrompt = `You are WasteMirror AI, a sustainability advisor for Mongolian users.

User waste profile:
- Discards ${items_per_week} items/week
- Primary waste type: ${dominant_waste_category}
- Recycling habit: ${recycling_habit}
- Lifestyle: ${lifestyle}
- Current recycling rate: ${recyclable_rate_percent}%
- Yearly waste estimate: ${yearly.total_waste_kg} kg
- Yearly landfill: ${yearly.landfill_kg} kg
- CO₂ emission per year: ${yearly.co2_emission_kg} kg

Respond ONLY with a JSON object, no markdown, no extra text:
{
  "summary_mn": "2-sentence summary of their waste situation in Mongolian",
  "summary_en": "2-sentence summary of their waste situation in English",
  "advice_mn": "3-4 sentences of specific, actionable advice tailored to their category and habit level. In Mongolian. Be encouraging but honest.",
  "advice_en": "3-4 sentences of specific, actionable advice tailored to their category and habit level. In English."
}`;

    const r = await groq.chat.completions.create({
      model: TEXT_MODEL,
      max_tokens: 600,
      temperature: 0.4,
      messages: [{ role: "user", content: advicePrompt }],
    });

    const raw = r.choices[0]?.message?.content ?? "{}";
    const cleaned = raw.replace(/```json\s*/gi, "").replace(/```\s*/gi, "").trim();
    const obj = JSON.parse(cleaned.match(/\{[\s\S]*\}/)?.[0] ?? "{}");
    summary_mn   = obj.summary_mn   ?? "";
    summary_en   = obj.summary_en   ?? "";
    ai_advice_mn = obj.advice_mn    ?? "";
    ai_advice_en = obj.advice_en    ?? "";
  } catch {
    // Fallback static text
    summary_mn   = `Та жилд ${yearly.total_waste_kg} кг хог хаягдал үүсгэж байна.`;
    summary_en   = `You generate approximately ${yearly.total_waste_kg} kg of waste per year.`;
    ai_advice_mn = "Хаягдлаа ангилж, дахин боловсруулах хэвшлийг нэмэгдүүлснээр нөлөөгөө эрс бууруулж чадна.";
    ai_advice_en = "Sorting and increasing your recycling habit can significantly reduce your environmental impact.";
  }

  return {
    baseline,
    improved,
    summary_mn,
    summary_en,
    ai_advice_mn,
    ai_advice_en,
    weekly_waste_kg:          parseFloat(weeklyWasteKg.toFixed(3)),
    recyclable_rate_percent,
  };
}
