import type { LeaderboardResponse, LeaderboardEntry, UserRewardState, Badge, RewardAction } from "./types";

// ─── Level system ──────────────────────────────────────────────────────────────
export const LEVELS = [
  { level: 1,  min_exp: 0,    name_mn: "Шинэхэн",        name_en: "Newcomer"       },
  { level: 2,  min_exp: 100,  name_mn: "Эко Анхлан",     name_en: "Eco Beginner"   },
  { level: 3,  min_exp: 250,  name_mn: "Ногоон Гарваа",  name_en: "Green Start"    },
  { level: 4,  min_exp: 500,  name_mn: "Дахин Ашиглагч", name_en: "Recycler"       },
  { level: 5,  min_exp: 900,  name_mn: "Хаягдлын Баатар",name_en: "Waste Hero"     },
  { level: 6,  min_exp: 1400, name_mn: "Эко Дайчин",     name_en: "Eco Warrior"    },
  { level: 7,  min_exp: 2000, name_mn: "Нөхөн Сэргэгч",  name_en: "Restorer"       },
  { level: 8,  min_exp: 3000, name_mn: "Дэлхийн Эзэн",   name_en: "Earth Guardian" },
  { level: 9,  min_exp: 4500, name_mn: "Устгагч Тэнгэр",  name_en: "Eco Legend"    },
  { level: 10, min_exp: 6500, name_mn: "Эко Аварга",      name_en: "Eco Champion"  },
];

export function getLevelFromExp(exp: number) {
  let current = LEVELS[0];
  for (const l of LEVELS) {
    if (exp >= l.min_exp) current = l;
  }
  const idx = LEVELS.indexOf(current);
  const next = LEVELS[idx + 1];
  return {
    ...current,
    next_level_exp: next?.min_exp ?? current.min_exp,
  };
}

// ─── Reward actions table ──────────────────────────────────────────────────────
export const REWARD_ACTIONS: RewardAction[] = [
  {
    action: "scan_item",
    points: 10,
    exp: 15,
    description_mn: "Зүйл скан хийх",
    description_en: "Scan an item",
  },
  {
    action: "follow_suggestion",
    points: 25,
    exp: 40,
    description_mn: "Зөвлөмжийг дагах",
    description_en: "Follow a suggestion",
  },
  {
    action: "daily_streak",
    points: 15,
    exp: 20,
    description_mn: "Өдөр тутмын серия",
    description_en: "Daily streak",
  },
  {
    action: "room_photo",
    points: 30,
    exp: 50,
    description_mn: "Өрөөний зураг авах",
    description_en: "Room photo challenge",
  },
  {
    action: "hazardous_correct",
    points: 60,
    exp: 90,
    description_mn: "Хортой хог зөв ангилах",
    description_en: "Correctly dispose hazardous waste",
  },
];

// ─── All badges ────────────────────────────────────────────────────────────────
export const ALL_BADGES: Badge[] = [
  {
    id: "first_scan",
    name_mn: "Анхны Скан",
    name_en: "First Scan",
    icon: "🔍",
    unlocked: false,
    description_mn: "Анхны хаягдлаа скан хийлээ",
    description_en: "Scanned your first waste item",
  },
  {
    id: "recycler_5",
    name_mn: "5 Дахин Боловсруулагч",
    name_en: "5x Recycler",
    icon: "♻️",
    unlocked: false,
    description_mn: "5 зүйлийг зөв ангилсан",
    description_en: "Correctly sorted 5 items",
  },
  {
    id: "eco_warrior",
    name_mn: "Эко Дайчин",
    name_en: "Eco Warrior",
    icon: "🌿",
    unlocked: false,
    description_mn: "1 кг CO₂ хэмнэсэн",
    description_en: "Saved 1 kg of CO₂",
  },
  {
    id: "room_cleaner",
    name_mn: "Өрөөний Баатар",
    name_en: "Room Hero",
    icon: "🏠",
    unlocked: false,
    description_mn: "Өрөөний зураг авсан",
    description_en: "Completed room photo challenge",
  },
  {
    id: "streak_7",
    name_mn: "7 Хоногийн Серия",
    name_en: "7-Day Streak",
    icon: "🔥",
    unlocked: false,
    description_mn: "7 хоног дараалан нэвтэрсэн",
    description_en: "Logged in 7 days in a row",
  },
  {
    id: "e_waste_hero",
    name_mn: "Э-Хог Баатар",
    name_en: "E-Waste Hero",
    icon: "📱",
    unlocked: false,
    description_mn: "3 цахим хаягдал зөв ангилсан",
    description_en: "Properly sorted 3 electronics",
  },
  {
    id: "level_5",
    name_mn: "Хаягдлын Баатар",
    name_en: "Waste Hero",
    icon: "⭐",
    unlocked: false,
    description_mn: "5-р түвшинд хүрсэн",
    description_en: "Reached level 5",
  },
  {
    id: "co2_saver_10",
    name_mn: "CO₂ Аварагч",
    name_en: "CO₂ Saver",
    icon: "🌍",
    unlocked: false,
    description_mn: "10 кг CO₂ хэмнэсэн",
    description_en: "Saved 10 kg of CO₂",
  },
];

// ─── Mock leaderboard data ─────────────────────────────────────────────────────
const MOCK_USERS: Omit<LeaderboardEntry, "rank">[] = [
  { username: "Болд.Б",      avatar: "🧑", level: 10, exp: 8200, coins: 1540, items_scanned: 87, co2_saved_kg: 42.3, badge: "Эко Аварга"        },
  { username: "Номин.Э",     avatar: "👩", level: 9,  exp: 6100, coins: 1120, items_scanned: 73, co2_saved_kg: 36.1, badge: "Устгагч Тэнгэр"     },
  { username: "Ганбаяр.Т",   avatar: "🧔", level: 8,  exp: 4800, coins: 890,  items_scanned: 61, co2_saved_kg: 28.7, badge: "Дэлхийн Эзэн"      },
  { username: "Саруул.Д",    avatar: "👧", level: 7,  exp: 3600, coins: 670,  items_scanned: 54, co2_saved_kg: 21.4, badge: "Нөхөн Сэргэгч"     },
  { username: "Энхбат.М",    avatar: "👨", level: 7,  exp: 3200, coins: 610,  items_scanned: 48, co2_saved_kg: 18.9, badge: "Нөхөн Сэргэгч"     },
  { username: "Өлзийбаяр.Г", avatar: "🧑", level: 6,  exp: 2100, coins: 420,  items_scanned: 39, co2_saved_kg: 14.2, badge: "Эко Дайчин"        },
  { username: "Тэмүүлэн.О",  avatar: "👦", level: 5,  exp: 1500, coins: 310,  items_scanned: 31, co2_saved_kg: 10.8, badge: "Хаягдлын Баатар"   },
  { username: "Мөнхзул.Б",   avatar: "👩", level: 4,  exp: 720,  coins: 180,  items_scanned: 22, co2_saved_kg: 6.3,  badge: "Дахин Ашиглагч"    },
  { username: "Дорж.С",      avatar: "🧔", level: 3,  exp: 430,  coins: 95,   items_scanned: 14, co2_saved_kg: 3.1,  badge: "Ногоон Гарваа"     },
  { username: "Хишигт.Н",    avatar: "👧", level: 2,  exp: 180,  coins: 45,   items_scanned: 7,  co2_saved_kg: 1.2,  badge: "Эко Анхлан"        },
];

export function getMockLeaderboard(): LeaderboardResponse {
  const entries: LeaderboardEntry[] = MOCK_USERS.map((u, i) => ({
    ...u,
    rank: i + 1,
    is_current_user: false,
  }));

  // Current user (demo) — middle of the pack
  const currentUser: LeaderboardEntry = {
    rank: 11,
    username: "Та (Жишээ)",
    avatar: "😊",
    level: 2,
    exp: 145,
    coins: 38,
    items_scanned: 5,
    co2_saved_kg: 0.9,
    badge: "Эко Анхлан",
    is_current_user: true,
  };

  return {
    entries: [...entries, currentUser].sort((a, b) => a.rank - b.rank),
    current_user: currentUser,
    total_users: 1284,
  };
}

// ─── Default user reward state ─────────────────────────────────────────────────
export function getDefaultUserRewards(): UserRewardState {
  const exp = 0;
  const levelInfo = getLevelFromExp(exp);
  return {
    coins: 0,
    exp,
    level: levelInfo.level,
    level_name_mn: levelInfo.name_mn,
    level_name_en: levelInfo.name_en,
    next_level_exp: levelInfo.next_level_exp,
    items_scanned: 0,
    co2_saved_kg: 0,
    streak_days: 0,
    badges: ALL_BADGES.map((b) => ({ ...b, unlocked: false })),
  };
}
