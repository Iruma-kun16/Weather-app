// ─── Waste Scan ────────────────────────────────────────────────────────────────

export type WasteCategory =
  | "electronics"
  | "plastic"
  | "paper"
  | "glass"
  | "metal"
  | "organic"
  | "textile"
  | "hazardous"
  | "furniture"
  | "mixed"
  | "unknown";

export type DisposalMethod =
  | "reusable"
  | "recyclable"
  | "repairable"
  | "donatable"
  | "sellable"
  | "compostable"
  | "landfill";

export interface WasteAction {
  method: DisposalMethod;
  title: string;           // e.g. "Засварын дэлгүүрт зар"
  title_en: string;
  description: string;     // Mongolian
  description_en: string;
  impact: string;          // e.g. "CO₂ 0.5 кг хэмнэнэ"
  impact_en: string;
  priority: "best" | "alternative";
}

export interface ScanResult {
  item_name: string;          // Mongolian
  item_name_en: string;
  category: WasteCategory;
  confidence: number;         // 0–100
  is_recyclable: boolean;
  is_hazardous: boolean;
  estimated_weight_kg: number;
  co2_saved_kg: number;       // if best action is taken
  actions: WasteAction[];
  fun_fact: string;           // Mongolian
  fun_fact_en: string;
  points_earned: number;      // gamification
  exp_earned: number;
}

export interface ScanRequest {
  image_base64: string;       // data:image/... or raw base64
  language?: "mn" | "en";
}

// ─── Prediction ────────────────────────────────────────────────────────────────

export type RecyclingHabit = "none" | "sometimes" | "often" | "always";
export type Lifestyle = "student" | "office" | "family" | "other";

export interface UserBehaviorInput {
  items_per_week: number;          // how many items discarded per week
  recycling_habit: RecyclingHabit;
  lifestyle: Lifestyle;
  dominant_waste_category: WasteCategory;
  scan_history?: ScannedItemSummary[]; // optional: from past scans
}

export interface ScannedItemSummary {
  category: WasteCategory;
  estimated_weight_kg: number;
  is_recyclable: boolean;
  disposed_correctly: boolean; // did the user follow the app's suggestion?
}

export interface PredictionPeriod {
  label: string;        // "1 сар" / "6 сар" / "1 жил"
  label_en: string;
  total_waste_kg: number;
  recyclable_kg: number;
  landfill_kg: number;
  co2_emission_kg: number;
  co2_saved_if_improved_kg: number;
  improvement_percent: number;
}

export interface PredictionResult {
  baseline: PredictionPeriod[];    // current behavior
  improved: PredictionPeriod[];    // if user follows app suggestions
  summary_mn: string;
  summary_en: string;
  ai_advice_mn: string;
  ai_advice_en: string;
  weekly_waste_kg: number;
  recyclable_rate_percent: number;
}

// ─── Leaderboard ───────────────────────────────────────────────────────────────

export interface LeaderboardEntry {
  rank: number;
  username: string;
  avatar: string;       // emoji or url
  level: number;
  exp: number;
  coins: number;
  items_scanned: number;
  co2_saved_kg: number;
  badge: string;        // e.g. "Эко Аварга"
  is_current_user?: boolean;
}

export interface LeaderboardResponse {
  entries: LeaderboardEntry[];
  current_user: LeaderboardEntry;
  total_users: number;
}

// ─── Rewards ───────────────────────────────────────────────────────────────────

export interface RewardAction {
  action: string;
  points: number;
  exp: number;
  description_mn: string;
  description_en: string;
}

export interface UserRewardState {
  coins: number;
  exp: number;
  level: number;
  level_name_mn: string;
  level_name_en: string;
  next_level_exp: number;
  items_scanned: number;
  co2_saved_kg: number;
  streak_days: number;
  badges: Badge[];
}

export interface Badge {
  id: string;
  name_mn: string;
  name_en: string;
  icon: string;
  unlocked: boolean;
  description_mn: string;
  description_en: string;
}

// ─── API Response wrappers ─────────────────────────────────────────────────────

export interface ApiSuccess<T> {
  success: true;
  data: T;
}

export interface ApiError {
  success: false;
  error: string;
  code?: string;
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError;
